# OnTheGoServer

server and api endpoint for On The Go App by AVs team
